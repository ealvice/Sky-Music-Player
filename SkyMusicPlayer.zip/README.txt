SkyMusicPlayer is an application created to play instruments in Sky: Children of the Light on PC.
ABC1-5 files are required, and they can be created on https://sky-music.herokuapp.com/ or on the "Sky Studio" app on IOS and Android.

Java must be installed on your PC in order to run this program. You can find the download here: https://www.java.com/download/ie_manual.jsp
Additionally, you may need to create a new system path variable, JAVA_HOME to open the program. Here's how to do that: https://www.java.com/en/download/help/path.html

Sky PC uses keyboard input to play instruments, and as such, you should be careful of what window you have selected while using this program, as it could type gibberish in to any open textbox, or accidently trigger hotkeys. For reference, the keys used by this script are as follows: Y U I O P H J K L ; N M , . /
Make sure you always have the Sky window selected while playing. I would suggest only using this program while Sky is in Windowed mode.